<?php 

class Calculate {

    public function add($a , $b)
    {
       return $a + $b;
    }
}


?>